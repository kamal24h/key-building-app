﻿namespace AUA.ProjectName.ReportHandler.Utilities
{
    public interface IReportHandlerPathHelper
    {
        //Is needed for routing to Dll.
    }
}
