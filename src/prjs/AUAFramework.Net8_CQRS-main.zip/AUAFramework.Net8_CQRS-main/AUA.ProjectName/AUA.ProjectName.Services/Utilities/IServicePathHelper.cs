﻿namespace AUA.ProjectName.Services.Utilities
{
    public interface IServicePathHelper
    {
        //This is needed for routing path
    }
}
