﻿namespace AUA.ProjectName.Commands.Utilities
{
    public interface ICommandPathHelper
    {
        //Is needed for routing to Dll.
    }
}
