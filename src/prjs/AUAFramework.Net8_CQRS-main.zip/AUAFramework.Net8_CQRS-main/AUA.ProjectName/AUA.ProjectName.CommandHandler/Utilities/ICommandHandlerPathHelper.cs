﻿namespace AUA.ProjectName.CommandHandler.Utilities
{
    public interface ICommandHandlerPathHelper
    {
        //Is needed for routing to Dll.
    }
}
