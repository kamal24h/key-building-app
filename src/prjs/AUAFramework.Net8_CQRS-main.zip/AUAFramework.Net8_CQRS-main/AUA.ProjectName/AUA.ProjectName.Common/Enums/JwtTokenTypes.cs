﻿using System.ComponentModel;

namespace AUA.ProjectName.Common.Enums
{
  
    public enum EJwtTokenType
    {
        [Description("barrier")]
        Barrier = 1,
    }
}
