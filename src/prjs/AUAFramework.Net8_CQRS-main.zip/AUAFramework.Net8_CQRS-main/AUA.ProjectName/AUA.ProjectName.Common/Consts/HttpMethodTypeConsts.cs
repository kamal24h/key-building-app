﻿

namespace AUA.ProjectName.Common.Consts
{
    public class HttpMethodTypeConsts
    {
        public const string Post = "post";

        public const string Get = "get";

        public const string Delete = "delete";

        public const string Put = "put";
    }
}
