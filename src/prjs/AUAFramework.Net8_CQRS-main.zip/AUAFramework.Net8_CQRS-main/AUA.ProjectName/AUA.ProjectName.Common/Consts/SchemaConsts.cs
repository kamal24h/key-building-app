﻿namespace AUA.ProjectName.Common.Consts
{
    public class SchemaConsts
    {

        public const string Accounting = "acc";

        public const string Student = "stu";

        public const string Products = "products";



    }
}
