﻿namespace AUA.ProjectName.Common.Consts
{
    public static class LogSettingConsts
    {

        public const string LogSetting = "LogSetting";

        public const string SqlLogConnection = "SqlLogConnection";

        public const string IsEnableSqlServerLog = "IsEnableSqlServerLog";

    }
}
