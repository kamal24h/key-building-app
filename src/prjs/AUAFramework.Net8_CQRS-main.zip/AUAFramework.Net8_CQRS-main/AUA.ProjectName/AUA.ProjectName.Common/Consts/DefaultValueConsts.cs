﻿namespace AUA.ProjectName.Common.Consts
{
    public class DefaultValueConsts
    {
        public const int DefaultPageSize = 10;

        public const int DefaultPageNumber = 0;

        public const int DefaultRoleId = 2;

        public const long SystemUserId = 1;
    }
}
