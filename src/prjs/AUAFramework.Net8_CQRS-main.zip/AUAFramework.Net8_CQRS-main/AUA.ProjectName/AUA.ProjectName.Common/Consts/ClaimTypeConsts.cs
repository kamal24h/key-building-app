﻿
namespace AUA.ProjectName.Common.Consts
{
    public class ClaimTypeConsts
    {
        public const string AccountId = "AccountId";

        public const string ClientId = "ClientId";

        
    }
}
