﻿namespace AUA.ProjectName.Common.Consts
{
    public static class StoredProcedureConsts
    {
        public const string GetAppUsersCountSp = "uspGetAppUsersCountSp";

        public const string GetUserRolesSp = "uspGetUserRolesSp";
        
    }
}

