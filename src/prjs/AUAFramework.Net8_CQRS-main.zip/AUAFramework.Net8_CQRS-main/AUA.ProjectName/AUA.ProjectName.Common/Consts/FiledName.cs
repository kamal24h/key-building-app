﻿namespace AUA.ProjectName.Common.Consts
{
    public class FiledNameConsts
    {
        public const string Password = "password";

        public const string UserName = "username";
    }
}
