﻿namespace AUA.ProjectName.Common.Consts
{
    public class ApiVersionConsts
    {
        public const string V1 = "1";

        public const string V2 = "2";

        public const string V3 = "3";

    }
}
