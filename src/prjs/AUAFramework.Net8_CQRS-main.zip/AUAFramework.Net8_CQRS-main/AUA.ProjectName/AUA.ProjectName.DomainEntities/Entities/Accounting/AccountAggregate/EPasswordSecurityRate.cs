﻿namespace AUA.ProjectName.DomainEntities.Entities.Accounting.AccountAggregate
{
    public enum EPasswordSecurityRate
    {
        VeryWeak = 1,
        Weak = 2,
        Medium = 3,
        Strong = 4,
        VeryStrong = 5
    }
}
