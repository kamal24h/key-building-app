﻿
namespace AUA.ProjectName.DomainEntities.Entities.Accounting.AppUserAggregate
{
    public record UserContact(string Phone, string Email);
}
