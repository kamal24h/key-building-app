﻿using System;

namespace AUA.ProjectName.DomainEntities.Tools.BaseEntities
{
    public interface IAuditInfo
    {
        DateTime RegistrationDate { get; set; }


    }
}
