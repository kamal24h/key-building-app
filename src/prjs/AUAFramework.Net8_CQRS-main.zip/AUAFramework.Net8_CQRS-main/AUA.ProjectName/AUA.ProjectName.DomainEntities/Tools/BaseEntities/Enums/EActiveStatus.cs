﻿using System.ComponentModel;

namespace AUA.ProjectName.DomainEntities.Tools.BaseEntities.Enums
{
    public enum ERecordStatus
    {
        [Description("DeActive")]
        DeActive = 0,

        [Description("Active")]
        Active = 1

    }
}
