﻿namespace AUA.ProjectName.DomainEntities.Tools.BaseEntities
{
    public interface ICreationAudited
    {
        long? CreatorUserId { get; set; }

    }
}
