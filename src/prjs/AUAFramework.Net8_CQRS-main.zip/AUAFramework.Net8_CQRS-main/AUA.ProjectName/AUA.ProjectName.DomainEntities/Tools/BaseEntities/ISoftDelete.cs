﻿namespace AUA.ProjectName.DomainEntities.Tools.BaseEntities
{
    public interface ISoftDelete
    {
        bool IsDeleted { get; set; }

    }
}
