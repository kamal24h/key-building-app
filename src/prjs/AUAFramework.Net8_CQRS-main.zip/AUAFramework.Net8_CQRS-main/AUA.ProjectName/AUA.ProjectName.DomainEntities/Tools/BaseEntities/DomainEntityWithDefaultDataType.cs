﻿namespace AUA.ProjectName.DomainEntities.Tools.BaseEntities
{
    public class DomainEntity : DomainEntity<long>
    {

    }

}
