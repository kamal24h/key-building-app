﻿namespace AUA.ProjectName.QueryHandler.Utilities
{
    public interface IQueryHandlerPathHelper
    {
        //Is needed for routing to Dll.
    }
}
