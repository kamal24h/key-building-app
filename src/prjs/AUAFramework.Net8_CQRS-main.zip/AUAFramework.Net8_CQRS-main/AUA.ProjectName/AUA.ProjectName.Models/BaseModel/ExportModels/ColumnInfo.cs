﻿namespace AUA.ProjectName.Models.BaseModel.ExportModels
{
    public class ColumnInfo
    {
        public string PropertyName { get; set; }

        public string Caption { get; set; }
    }
}
