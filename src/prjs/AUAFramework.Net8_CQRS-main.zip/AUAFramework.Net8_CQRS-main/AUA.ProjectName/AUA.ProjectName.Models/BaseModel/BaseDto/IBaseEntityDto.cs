﻿using System;

namespace AUA.ProjectName.Models.BaseModel.BaseDto
{
    public interface IBaseEntityDto
    {
        DateTime RegistrationDate { get; }

    }
}
