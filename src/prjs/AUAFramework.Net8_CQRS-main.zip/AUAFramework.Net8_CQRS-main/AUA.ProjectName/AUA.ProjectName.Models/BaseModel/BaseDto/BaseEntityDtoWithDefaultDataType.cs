﻿namespace AUA.ProjectName.Models.BaseModel.BaseDto
{
    public class BaseEntityDto : BaseEntityDto<long>
    {
        
    }

}
