﻿namespace AUA.ProjectName.Models.BaseModel.BaseViewModels
{
    public class MessageProviderVm
    {
        public string MessageType { get; set; }

        public string Message { get; set; }
    }
}
