﻿using AUA.ProjectName.Common.Enums;
using AUA.ProjectName.DomainEntities.Entities.Accounting.AccessTokenAggregate;

namespace AUA.ProjectName.Models.BaseModel.BaseViewModels
{
    public class GeneralBaseVm 
    {
        public EAppType AppTypeCode { get; set; }
    }
}