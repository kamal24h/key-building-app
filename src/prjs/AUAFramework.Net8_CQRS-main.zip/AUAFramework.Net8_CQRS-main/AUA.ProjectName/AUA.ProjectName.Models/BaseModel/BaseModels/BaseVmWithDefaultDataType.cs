﻿namespace AUA.ProjectName.Models.BaseModel.BaseViewModels
{
    public class BaseVm : BaseVm<int>
    {
       

    }
}
