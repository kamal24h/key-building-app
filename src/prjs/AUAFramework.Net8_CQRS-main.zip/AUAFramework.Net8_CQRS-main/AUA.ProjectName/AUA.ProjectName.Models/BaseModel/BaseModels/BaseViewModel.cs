﻿namespace AUA.ProjectName.Models.BaseModel.BaseViewModels
{
    public class BaseViewModel
    {


    }
}
