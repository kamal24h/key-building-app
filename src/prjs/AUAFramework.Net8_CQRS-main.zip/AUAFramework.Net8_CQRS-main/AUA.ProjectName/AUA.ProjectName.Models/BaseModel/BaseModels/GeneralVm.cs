﻿namespace AUA.ProjectName.Models.BaseModel.BaseViewModels
{
    public class GeneralVm<TPrimaryKey> : GeneralBaseVm
    {
        public TPrimaryKey Id { get; set; }

    }
}