﻿namespace AUA.ProjectName.Models.BaseModel.BaseViewModels
{
    public class GeneralVm : GeneralVm<int>
    {


    }
}