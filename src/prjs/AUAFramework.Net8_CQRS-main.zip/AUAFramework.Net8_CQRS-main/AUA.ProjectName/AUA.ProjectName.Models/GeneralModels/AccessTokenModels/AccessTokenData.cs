﻿namespace AUA.ProjectName.Models.GeneralModels.AccessTokenModels
{
    public class AccessTokenData
    {
        public long UserId { get; set; }

        public DateTime ExpirationDate { get; set; }

    }
}
