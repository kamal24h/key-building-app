﻿using AUA.ProjectName.Models.BaseModel.BaseViewModels;

namespace AUA.ProjectName.Models.GeneralModels.GeneralVm
{
    public class NullObjectPattern : BaseViewModel
    {

    }
}
