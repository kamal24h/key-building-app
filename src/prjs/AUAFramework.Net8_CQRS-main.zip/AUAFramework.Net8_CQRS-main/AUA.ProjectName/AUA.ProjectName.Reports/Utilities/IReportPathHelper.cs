﻿namespace AUA.ProjectName.Reports.Utilities
{
    public interface IReportPathHelper
    {
        //Is needed for routing to Dll.
    }
}
