﻿namespace AUA.ProjectName.Queries.Queries.Accounting.UserAccounts
{
    public class UserAccountQueryResponse
    {
        public string UserName { get; set; }

    }
}
