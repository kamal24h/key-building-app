﻿using System.ComponentModel;

namespace AUA.ProjectName.Queries.Queries.Accounting.UserAccounts;

public enum UserAccountQueryResultStatus
{
    [Description("Success")]
    Success = 0,

}