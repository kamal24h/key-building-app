﻿namespace AUA.ProjectName.Queries.Queries.Accounting.UserContacts
{
    public class UserContactQueryResponse
    {
        public string Phone { get; set; }

        public string Email { get; set; }

    }
}
