﻿using System.ComponentModel;

namespace AUA.ProjectName.Queries.Queries.Accounting.UserContacts;

public enum UserContactQueryResultStatus
{
    [Description("Success")]
    Success = 0,

}