﻿namespace AUA.ProjectName.Queries.Utilities
{
    public interface IQueryPathHelper
    {
        //Is needed for routing to Dll.
    }
}
