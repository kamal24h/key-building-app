export class FileInfo {
    constructor(public id: string, public name: string) { }
}
