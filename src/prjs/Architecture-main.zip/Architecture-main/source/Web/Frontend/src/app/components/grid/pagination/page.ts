export class Page {
    constructor(public index: number = 1, public size: number = 10) { }
}
