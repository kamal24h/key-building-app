export class Upload {
    constructor(public id: string, public progress: number) { }
}
