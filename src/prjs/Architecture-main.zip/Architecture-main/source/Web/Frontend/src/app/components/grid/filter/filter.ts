export class Filter {
    constructor(public property: string, public comparison: string, public value: any) { }
}
