export class Option {
    constructor(public value: any, public text: string) { }
}
