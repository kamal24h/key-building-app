export class SignIn {
    login!: string;
    password!: string;
}
