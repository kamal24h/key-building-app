export class Order {
    constructor(public property: string = "", public ascending: boolean = true) { }
}
