export class Settings {
    readonly api!: string;
}
