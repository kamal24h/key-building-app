namespace Architecture.Model;

public sealed record SignInModel(string Login, string Password);
