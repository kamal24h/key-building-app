namespace Architecture.Model;

public sealed record AuthModel(string Login, string Password, int Roles);
