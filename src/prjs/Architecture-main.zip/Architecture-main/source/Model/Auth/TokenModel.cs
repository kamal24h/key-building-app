namespace Architecture.Model;

public sealed record TokenModel(string Token);
