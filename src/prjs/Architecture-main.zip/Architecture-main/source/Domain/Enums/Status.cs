namespace Architecture.Domain;

public enum Status
{
    None = 0,
    Active = 1,
    Inactive = 2
}
