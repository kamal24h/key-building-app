namespace Architecture.Domain;

public sealed record Email(string Value);
