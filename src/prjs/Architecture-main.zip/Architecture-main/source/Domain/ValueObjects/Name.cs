namespace Architecture.Domain;

public sealed record Name(string FirstName, string LastName);
