import { ABP } from '@abp/ng.core';

export const DefaultOption = {
  value: null,
  key: '-',
} as ABP.Option<any>;
