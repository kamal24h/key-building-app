export enum eBooksComponents {
  Books = 'Books',
  RentBook = 'Books.RentBook',
}
