export * from './rent-book/rent-book.component';
