// This file is part of BookClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Acme.BookStore.Books.ClientProxies;

public partial class BookClientProxy
{
}
