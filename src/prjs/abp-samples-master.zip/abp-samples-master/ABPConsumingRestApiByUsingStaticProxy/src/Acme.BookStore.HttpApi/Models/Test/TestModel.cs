﻿using System;

namespace Acme.BookStore.Models.Test;

public class TestModel
{
    public string Name { get; set; }

    public DateTime BirthDate { get; set; }
}
