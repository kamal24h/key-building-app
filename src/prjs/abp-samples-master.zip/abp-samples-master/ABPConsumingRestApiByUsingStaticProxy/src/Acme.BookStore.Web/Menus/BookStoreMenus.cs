﻿namespace Acme.BookStore.Web.Menus;

public static class BookStoreMenus
{
    private const string Prefix = "BookStore";
    public const string Home = Prefix + ".Home";

    public const string Books = Prefix + ".Books";

    //Add your menu items here...

}
