# How to Design Multi-Lingual Entity

This is an example project that demonstrates how to Design Multi-Lingual Entity. See the article that explain this project:

**https://community.abp.io/posts/how-to-design-multilingual-entity-8glnk6vu**
