﻿namespace Acme.BookStore.Web.Pages
{
    public class IndexModel : BookStorePageModel
    {
        public void OnGet()
        {
            
        }
    }
}