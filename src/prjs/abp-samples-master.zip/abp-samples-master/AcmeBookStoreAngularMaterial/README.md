# Using Angular Material Components With the ABP Framework

This is an example project that demonstrates using Angular Material Components With the ABP Framework. See the article that explain this project:

**https://community.abp.io/posts/using-angular-material-components-with-the-abp-framework-af8ft6t9**