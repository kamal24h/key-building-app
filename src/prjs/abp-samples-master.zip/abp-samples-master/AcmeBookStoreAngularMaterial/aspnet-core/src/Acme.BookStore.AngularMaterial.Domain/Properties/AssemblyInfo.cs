﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Acme.BookStore.AngularMaterial.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("Acme.BookStore.AngularMaterial.TestBase")]
