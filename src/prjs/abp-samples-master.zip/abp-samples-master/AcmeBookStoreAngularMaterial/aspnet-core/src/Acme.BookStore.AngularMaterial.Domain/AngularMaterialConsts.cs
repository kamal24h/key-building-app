﻿namespace Acme.BookStore.AngularMaterial
{
    public static class AngularMaterialConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
