﻿using Volo.Abp.Localization;

namespace Acme.BookStore.AngularMaterial.Localization
{
    [LocalizationResourceName("AngularMaterial")]
    public class AngularMaterialResource
    {

    }
}