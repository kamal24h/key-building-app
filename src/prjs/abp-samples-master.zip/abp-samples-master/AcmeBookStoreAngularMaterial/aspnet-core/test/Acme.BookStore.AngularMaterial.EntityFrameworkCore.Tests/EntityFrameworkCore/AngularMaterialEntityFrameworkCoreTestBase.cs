﻿using Volo.Abp;

namespace Acme.BookStore.AngularMaterial.EntityFrameworkCore
{
    public abstract class AngularMaterialEntityFrameworkCoreTestBase : AngularMaterialTestBase<AngularMaterialEntityFrameworkCoreTestModule> 
    {

    }
}
