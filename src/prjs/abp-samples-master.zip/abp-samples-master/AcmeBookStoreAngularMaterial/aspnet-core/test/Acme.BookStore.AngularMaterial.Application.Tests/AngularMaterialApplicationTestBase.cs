﻿namespace Acme.BookStore.AngularMaterial
{
    public abstract class AngularMaterialApplicationTestBase : AngularMaterialTestBase<AngularMaterialApplicationTestModule> 
    {

    }
}
