import * as Authors from './authors';
import * as Books from './books';
export { Authors, Books };
