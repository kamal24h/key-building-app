﻿namespace CleanArchitecture.Domain.Constants;

public abstract class Policies
{
    public const string CanPurge = nameof(CanPurge);
}