﻿using System;

namespace Northwind.Common
{
    public interface IDateTime
    {
        DateTime Now { get; }
    }
}
