import { Component } from '@angular/core';

@Component({
  selector: 'app-nav-side-menu',
  templateUrl: './nav-side-menu.component.html'
})
export class NavSideMenuComponent {
}
