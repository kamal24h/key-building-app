import { Component } from '@angular/core';

@Component({
  selector: 'app-nav-top-menu',
  templateUrl: './nav-top-menu.component.html'
})
export class NavTopMenuComponent {
}
