﻿using System;

namespace AspNetCoreSpa.Common
{
    public interface IDateTime
    {
        DateTime Now { get; }
    }
}
