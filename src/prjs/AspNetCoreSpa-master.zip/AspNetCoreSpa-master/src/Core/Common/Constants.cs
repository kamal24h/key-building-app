﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetCoreSpa.Common
{
    public class Constants
    {
        public static string DefaultCorsPolicy = nameof(DefaultCorsPolicy);
    }
}
