﻿namespace AspNetCoreSpa.Application.Models
{
    public class ClientInfo
    {
        public string ClientId { get; set; }
        public string ClientUri { get; set; }
    }
}
