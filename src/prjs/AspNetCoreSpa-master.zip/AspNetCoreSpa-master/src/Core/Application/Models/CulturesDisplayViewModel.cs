﻿namespace AspNetCoreSpa.Application.Models
{
    public class CulturesDisplayViewModel
    {
        public string Value { get; set; }
        public string Text { get; set; }
        public bool Current { get; set; }
    }
}
