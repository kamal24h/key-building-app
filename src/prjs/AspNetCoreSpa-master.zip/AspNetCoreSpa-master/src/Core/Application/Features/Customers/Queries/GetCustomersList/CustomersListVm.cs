﻿using System.Collections.Generic;

namespace AspNetCoreSpa.Application.Features.Customers.Queries.GetCustomersList
{
    public class CustomersListVm
    {
        public IList<CustomerLookupDto> Customers { get; set; }
    }
}
