﻿using MediatR;

namespace AspNetCoreSpa.Application.Features.Products.Queries.GetProductsFile
{
    public class GetProductsFileQuery : IRequest<ProductsFileVm>
    {
    }
}
