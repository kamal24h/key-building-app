﻿/// <autosync enabled="true" />
/// <reference path="js/site.js" />
/// <reference path="../node_modules/bootstrap/dist/js/bootstrap.js" />
/// <reference path="../node_modules/jquery/dist/jquery.js" />
/// <reference path="../node_modules/jquery-validation/dist/jquery.validate.js" />
/// <reference path="../node_modules/jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.js" />
