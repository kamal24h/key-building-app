namespace AspNetCoreSpa.Web.ViewModels
{
    public enum Gender
    {
        None,
        Female,
        Male
    }
}