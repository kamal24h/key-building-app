export interface IAccordionItem {
  title: string;
  description: string;
}
