import { Component } from '@angular/core';

@Component({
  selector: 'appc-signalr',
  templateUrl: './signalr.component.html',
  styleUrls: ['./signalr.component.scss'],
})
export class SignalrComponent {}
