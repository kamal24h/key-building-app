import { Component } from '@angular/core';

@Component({
  selector: 'appc-privacy-component',
  templateUrl: './privacy.component.html'
})

export class PrivacyComponent { }
