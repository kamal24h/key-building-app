import { Component } from '@angular/core';

import { FieldBaseComponent } from '../field-base';

@Component({
  selector: 'app-form-file-path',
  styleUrls: ['form-file-path.component.scss'],
  templateUrl: 'form-file-path.component.html',
})
export class FormFilePathComponent extends FieldBaseComponent {}
