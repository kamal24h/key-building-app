import { Component } from '@angular/core';

import { FieldBaseComponent } from '../field-base';

@Component({
  selector: 'app-form-time',
  styleUrls: ['form-time.component.scss'],
  templateUrl: 'form-time.component.html',
})
export class FormTimeComponent extends FieldBaseComponent {}
