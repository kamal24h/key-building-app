export * from './modal-template.directive';
export * from './modal.component';
