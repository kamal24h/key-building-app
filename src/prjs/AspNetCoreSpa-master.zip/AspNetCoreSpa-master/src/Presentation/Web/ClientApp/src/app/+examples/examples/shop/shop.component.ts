import { Component } from '@angular/core';

@Component({
  selector: 'appc-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.scss'],
})
export class ShopComponent {}
