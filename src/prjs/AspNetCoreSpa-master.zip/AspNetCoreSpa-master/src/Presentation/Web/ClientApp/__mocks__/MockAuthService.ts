export class MockAuthService { }
