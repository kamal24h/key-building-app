module.exports = 'test-image-stub';
