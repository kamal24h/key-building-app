import { Component } from '@angular/core';

@Component({
  selector: 'appc-home-component',
  templateUrl: './home.component.html'
})

export class HomeComponent { }
