import { Component } from '@angular/core';

import { FieldBaseComponent } from '../field-base';

@Component({
  selector: 'app-form-file',
  styleUrls: ['form-file.component.scss'],
  templateUrl: 'form-file.component.html',
})
export class FormFileComponent extends FieldBaseComponent {}
