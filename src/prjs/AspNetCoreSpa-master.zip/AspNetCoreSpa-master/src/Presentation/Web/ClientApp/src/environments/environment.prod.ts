export const environment = {
  production: true,
  stsUrl: 'https://identityserver.fullstackpro.co.uk/',
};
