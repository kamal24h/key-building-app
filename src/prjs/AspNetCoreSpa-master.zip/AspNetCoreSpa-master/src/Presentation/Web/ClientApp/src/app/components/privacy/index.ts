export * from './privacy.component';
