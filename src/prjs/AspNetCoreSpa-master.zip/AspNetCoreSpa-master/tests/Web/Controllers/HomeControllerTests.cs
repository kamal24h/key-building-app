﻿using Xunit;

namespace AspNetCoreSpa.Web.Tests.Controllers
{
    public class HomeControllerTests
    {
        [Fact]
        public void DummyTest()
        {
            Assert.True(true);
        }
    }
}
